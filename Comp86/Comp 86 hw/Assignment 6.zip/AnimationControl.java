
// import javax.swing.JCheckBox;
// import java.awt.event.ActionListener;
// import java.awt.event.ActionEvent;

// public class AnimationControl extends JCheckBox implements ActionListener{
//     Canvas canvas;
//     Model model;
//     Boolean check = true;

//     public AnimationControl(Model m, Canvas c) {
//         setText("Run the Animation");
//         this.canvas = c;
//         this.model = m;
//         addActionListener (this);
//     }

//     public void actionPerformed (ActionEvent e) {
//         check = !check;
//         model.control_animation();
//         System.out.println("The Run Animation Box has been checked, value is: " + check);
//         canvas.repaint();
//     }


// }
