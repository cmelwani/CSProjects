//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a canvas in order to draw on the panel. 
//This class is called in Main.java 

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class Canvas extends JPanel {
    // This is the draw callback
    public void paintComponent (Graphics g) { 
	super.paintComponent(g); 
	g.drawLine (50, 50, 100, 50); 
    }
}
