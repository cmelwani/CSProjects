//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a canvas in order to draw everything and uses
//the repaint feature.
//This class calls Model which holds all of the data. 
//This class is called in Main.java 

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class Canvas extends JPanel {
    // This is the draw callback
    public Model model;
    Canvas(Model m) {
        this.model = m;
    }

    public void paintComponent (Graphics g) { 
        super.paintComponent(g); 
        model.draw(g);
        repaint();
    }

}
