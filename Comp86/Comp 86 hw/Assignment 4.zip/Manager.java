//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file sets up the object Manager that has a specific 
//icon and features. It extends JPanel and an is called in Model. 

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Manager extends Vehicle {
    ImageIcon icon1;
    Manager() {
        icon1 = new ImageIcon ("manager.png");
    }

    private int row;
    private int column;
    public void move(int x, int y) {
        row = x;
        column = y;
    }

    public void draw(Graphics g) {
        icon1.paintIcon(this, g, row, column);
    }
}