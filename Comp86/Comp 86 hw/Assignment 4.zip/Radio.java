//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a RadioButton class that sets up the Radio
//Button widget. This class is called in Main.java

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

public class Radio extends JPanel implements ItemListener { 
    public Radio () {
	// Border around our JPanel
	setBorder (new LineBorder(Color.BLUE, 1)); 

	ButtonGroup g = new ButtonGroup (); 

	JRadioButton rb = new JRadioButton ("Bring to their station", false); 
	add (rb); 
	g.add (rb); 
	rb.addItemListener (this); 

	rb = new JRadioButton ("Bring outside", true); 
	add (rb); 
	g.add (rb); 
	rb.addItemListener (this); 

	rb = new JRadioButton ("Socially distance", false); 
	add (rb); 
	g.add (rb); 
	rb.addItemListener (this); 

	rb = new JRadioButton ("Take a break", false); 
	add (rb); 
	g.add (rb); 
	rb.addItemListener (this); 
    }
    
    public void itemStateChanged (ItemEvent e) {
	// Reports every select or deselect, we filter out
		if (e.getStateChange()==ItemEvent.SELECTED) {
	   		System.out.println ("Radio: " + ((JRadioButton)e.getItem()).getText()); 
		}
    }
}
