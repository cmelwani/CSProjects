//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a Custodian which is a type of vehicle.
//This class extends from the Vehicle class which is its parent class. 

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Custodian extends Vehicle{
    ImageIcon icon1;
    Custodian() {
        icon1 = new ImageIcon ("janitor.png");
    }

    private int row;
    private int column;
    public void move(int x, int y) {
        row = x;
        column = y;
    }

    public void draw(Graphics g) {
        icon1.paintIcon(this, g, row, column);
    }
}
