//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a Model class that holds all of 
//the data necessary to create the simulation. 
//Instances of vehicles are created in this class. 
//An instance of Module is created in main.

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

public class Model {
    ArrayList<Vehicle> v = new ArrayList<Vehicle>();
    Worker worker1;
    Manager manager1;
    Custodian custodian1;
    Background b;
    Model() {
        worker1 = new Worker();
        manager1 = new Manager();
        custodian1 = new Custodian();
        worker1.move(400, 300);
        manager1.move(500, 500);
        custodian1.move(500, 200);
        v.add (worker1);
        v.add (manager1);
        v.add (custodian1);

        b = new Background();
    }

    public void draw (Graphics g) {
       b.draw(g);
        for (Vehicle vehicles: v) {
            vehicles.draw(g);
        }
    }


    public void move_vehicle(int x, int y, String v) {
        if(v.equals("Factory Worker 1")) {
            worker1.move(x,y);
        }
        //haven't gotten the buttons to work to move the manager or custodian
        else if(v.equals("Manager 1")) {
            manager1.move(x,y);
        }
        else if(v.equals("Custodian 1")) {
            custodian1.move(x,y);
        }
    }
}
