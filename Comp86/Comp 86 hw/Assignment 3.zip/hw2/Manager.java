//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file sets up the object Manager that has a specific 
//icon and features. It extends JPanel and an instance of Manager is created
//in main. 

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Manager extends JPanel{
    ImageIcon icon1;
    Manager() {
        icon1 = new ImageIcon ("manager.png");
    }

    public void draw(Graphics g) {
        icon1.paintIcon(this, g, 100, 100);
    }
}