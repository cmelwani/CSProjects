//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates instances of other classes. It calls 
//Button.java, ComboBox.java, Radio.java, and Canvas.java. 
//This file sets up the window, and the layout of the window as well as 
//the panels.

import javax.swing.*;
import java.awt.*;
import java.awt.FlowLayout;

public class Main extends JFrame {
    public static void main (String [] args) {
        java.awt.EventQueue.invokeLater (new Runnable() {
            public void run() {
		        new Main (); //creates an instance of main
            }
        });
    }

    public Main () {
        setSize (600, 700); //sets the window size 
        setLayout (new BorderLayout()); //sets layout of window

        JPanel p2 = new JPanel(new GridLayout(7,1,10,5));
        //changing the size of the panel 
        JPanel p3 = new JPanel();

        Manager m1 = new Manager ();
        Worker w2 = new Worker ();
        Canvas c1 = new Canvas (m1, w2);
        add(c1, BorderLayout.CENTER);

        add(p2, BorderLayout.EAST);
        add(p3, BorderLayout.SOUTH);
        p2.setBackground(Color.black);
        p3.setBackground(Color.black);

        ComboBox choose_worker = new ComboBox(); //creating an instance 
        p2.add(choose_worker);

        Button right = new Button ("Move Right"); 
        p2.add(right);
        Button left = new Button ("Move Left");
        p2.add(left);
        Button down = new Button ("Move Down");
        p2.add(down);
        Button up = new Button ("Move Up");
        p2.add(up);
        Button stop = new Button ("Stop");
        p2.add(stop); 
        Button quit = new Button ("Quit");
        p2.add(quit);

        Radio actions = new Radio();
        p3.add(actions);
        

        setVisible (true); //shows the window when you run the progam
        setDefaultCloseOperation (EXIT_ON_CLOSE); //closes window
    }
}