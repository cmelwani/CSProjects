//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a Button class that sets up the Button 
//widget. This class is called in Main.java

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;

public class Button extends JButton implements ActionListener { 
    public Button (String label) {
        setText (label);
        addActionListener (this);
        Color maroon = new Color (128, 0, 0);
        //found it on the internt to find the color maroon. 
        setForeground(maroon);
        setFont(new Font("Times New Roman", Font.BOLD, 14));
    }

    public void actionPerformed (ActionEvent e) { 
        System.out.println ("The " + getText() + " button was pushed"); 
    }
}
