//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates the object Worker that extends JPanel.
//Instances of this object is created in main and Worker has its own features.

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Worker extends JPanel{
    ImageIcon icon1;
    Worker() {
        icon1 = new ImageIcon ("worker.png");
    }

    public void draw(Graphics g) {
        icon1.paintIcon(this, g, 700, 100);
    }
}