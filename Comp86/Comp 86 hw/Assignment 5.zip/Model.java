//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a Model class that holds all of 
//the data necessary to create the simulation. 
//Instances of vehicles are created in this class. 
//An instance of Module is created in main.

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

public class Model {
    ArrayList<Vehicle> v = new ArrayList<Vehicle>();
    Worker worker1;
    Manager manager1;
    Custodian custodian1;
    Background b;
    private Canvas canvas;
    private Main parent;
    private boolean animation_on;

    Model(Canvas canvas, Main parent) {
        this.canvas = canvas;
        this.parent = parent;
        worker1 = new Worker(parent, 200, 200);
        manager1 = new Manager(parent, 300, 200);
        custodian1 = new Custodian(parent, 400, 200);
        worker1.move(200, 200);
        manager1.move(300, 200);
        custodian1.move(400, 200);
        v.add (worker1);
        v.add (manager1);
        v.add (custodian1);        
        b = new Background();
    }

    public void draw (Graphics g) {
       b.draw(g);
        for (Vehicle vehicles: v) {
            vehicles.draw(g);
        }
    }

    public void control_animation() {
        this.animation_on = !this.animation_on;
    }

    public void animate () {
        if(animation_on) {
            for (Vehicle vehicles: v) {
                vehicles.tick();
            }
        }
    }

    public void move_vehicle(int x, int y, String v) {
        if(v.equals("Factory Worker 1")) {
            worker1.move(x,y);
            canvas.repaint();
        }
        //haven't gotten the buttons to work to move the manager or custodian
        else if(v.equals("Manager 1")) {
            manager1.move(x,y);
            canvas.repaint();
        }
        else if(v.equals("Custodian 1")) {
            custodian1.move(x,y);
            canvas.repaint();
        }
    }

    public void addVehicle(String v_type) {
        int counter1 = 1;
        int counter2 = 1;
        int counter3 = 1;
        if(v_type == "Factory Worker") {
            counter1++;
            Worker worker = new Worker(parent, 200*counter1, 200);
            v.add(worker);
        }
        else if(v_type == "Manager") {
            counter2++;
            Manager manager = new Manager(parent, 300*counter2, 200);
            v.add(manager);
        }
        else if(v_type == "Custodian") {
            counter3++;
            Custodian custodian = new Custodian(parent, 400*counter3, 200);
            v.add(custodian);
        }
    }

}
