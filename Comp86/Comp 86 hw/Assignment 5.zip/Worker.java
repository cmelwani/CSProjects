//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates the object Worker that extends JPanel.
//Instances of this object is created in Module and Worker has its own features.

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Worker extends Vehicle{

    ImageIcon icon1;
    private Main parent;

    private int row;
    private int column;

    Worker (Main parent, int x, int y) {
        this.row = x;
        this.column = y;
        this.parent = parent;
        icon1 = new ImageIcon ("worker.png");
    }

    public int getX() {
        return row;
    }

    public int getY() {
        return column;
    }

    public void move(int x, int y) {
        row = x;
        column = y;
    }

    public void tick() {
        row = row + (20 + parent.getFrameNumber());
        column = column + (20 + parent.getFrameNumber());      
    }

    public void draw(Graphics g) {
        icon1.paintIcon(this, g, row, column);
    }
}