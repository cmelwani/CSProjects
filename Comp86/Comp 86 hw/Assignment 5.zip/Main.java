//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates instances of other classes. It calls 
//Button.java, ComboBox.java, Radio.java, and Canvas.java and more.
//This file sets up the window, and the layout of the window as well as 
//the panels.

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.FlowLayout;

public class Main extends JFrame implements ActionListener {
    public static void main (String [] args) {
        java.awt.EventQueue.invokeLater (new Runnable() {
            public void run() {
		        new Main (); //creates an instance of main
            }
        });
    }

    private Canvas c1;
    private Model model;

    public Main () {
        setSize (600, 700); //sets the window size 
        setLayout (new BorderLayout()); //sets layout of window

        JPanel p2 = new JPanel(new GridLayout(7,1,10,5));
        //changing the size of the panel 
        JPanel p3 = new JPanel();

        c1 = new Canvas (this);
        model = new Model (c1, this);
        c1.setModel (model);

        add(c1, BorderLayout.CENTER);

        add(p2, BorderLayout.EAST);
        add(p3, BorderLayout.SOUTH);
        p2.setBackground(Color.black);
        p3.setBackground(Color.black);


        ComboBox choose_worker = new ComboBox(); //creating an instance 
        p2.add(choose_worker);

        Button right = new Button ("Move Right", model); 
        p2.add(right);
        Button left = new Button ("Move Left", model);
        p2.add(left);
        Button down = new Button ("Move Down", model);
        p2.add(down);
        Button up = new Button ("Move Up", model);
        p2.add(up);
        Button start_animation = new Button ("Start Animation", model);
        p2.add(start_animation); 
        Button add_worker = new Button ("Add Worker", model);
        p2.add(add_worker);
        Button add_manager = new Button ("Add Manager", model);
        p2.add(add_manager);
        Button add_custodian = new Button ("Add Custodian", model);
        p2.add(add_custodian);

        TextField speed = new TextField();
        p3.add(speed);
        Radio actions = new Radio();
        p3.add(actions);

        Timer timer = new Timer (100, this);
        timer.start();

        setVisible (true); //shows the window when you run the progam
        setDefaultCloseOperation (EXIT_ON_CLOSE); //closes window
    }

    private int frameNumber = 1;

    public int getFrameNumber() {
        return frameNumber;
    }

    public void actionPerformed (ActionEvent e) {
        frameNumber++;
        model.animate();
        c1.repaint ();
    }
   

}