//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a Button class that sets up the Button 
//widget. This class is called in Main.java. This button shifts 
//the Factory Worker on the screen. 

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;

public class Button extends JButton implements ActionListener { 
    
    private Model model;
    private boolean check = true;

    public Button (String label, Model m) {
        this.model = m;
        setText (label);
        addActionListener (this);
        Color maroon = new Color (128, 0, 0);
        //found it on the internt to find the color maroon. 
        setForeground(maroon);
        setFont(new Font("Times New Roman", Font.BOLD, 14));
    }

    public void actionPerformed (ActionEvent e) { 
        System.out.println ("The " + getText() + " button was pushed"); 
        String text = (String)e.getActionCommand();
        if(text.equals("Move Left")) {
            model.move_vehicle(200, 300, "Factory Worker 1");
        } 
        else if(text.equals("Move Right")) {
            model.move_vehicle(600, 300, "Factory Worker 1");
        }
        else if(text.equals("Move Up")) {
            model.move_vehicle(400, 200, "Factory Worker 1");
        }
        else if(text.equals("Move Down")) {
            model.move_vehicle(400, 400, "Factory Worker 1");
        }
        else if(text.equals("Start Animation")) {
            check = !check;
            model.control_animation();
            JButton b = (JButton) e.getSource();
            b.setText("Stop Animation");
        }
        else if(text.equals("Stop Animation")) {
            check = !check;
            model.control_animation();
            JButton b = (JButton) e.getSource(); //stores clicked button
            b.setText("Start Animation"); //changes label of button
        }
        else if(text.equals("Add Worker")) {
            model.addVehicle("Factory Worker");
        }
        else if(text.equals("Add Manager")) {
            model.addVehicle("Manager");
        }
        else if(text.equals("Add Custodian")) {
            model.addVehicle("Custodian");
        }
    }
}
        

