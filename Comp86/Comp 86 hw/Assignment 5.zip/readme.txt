
Details:
    Cheryl Melwani
    Comp86 Assignment 5
    Sophomore Class (Year of 2023)
    
Instructions on how to compile and run your program.
Step 1: javac Main.java
Step 2: java Main 

Description of the kind of simulation (i.e theme, layout, types of vehicles).

This program will be a simulation of a factory during this pandemic.
The type of factory is still to be determined.
There will be different types of workers, managers, and custodials that 
are the "vehicles" in the program. The different vehicles will have 
different capabilities. The map will be the factory and I plan to have 
different sections of the factory outlined for different purposes. 
The simulation will also take into account the pandemic where social 
distancing guidelines will be implemented by the software (but I'm still 
unclear on the specific details of how).
 
Description of User Interface, and how it will work/what it will do.

The user interface will have buttons that will be able to do different
features such as move a vehicle or stop them from moving. 
The interface will also have a combobox or drop down menu that allows 
the user to pick the specific vehicle that they'd like to move or change
(the functionality of the combobox still needs to be implemented).
There is also a radio button widget that will allow the user to move
the vehicle upbrutly whether it be to the outside, or to socially distance
6 ft from other co-workers. There will be other features implemented in the 
future and some features changed depending on what we learn in the future. 


I added a Manager, Worker, and Custodian class that all extends from the
super class Vehicle. Vehicle holds all the functionalities that my 
3 vehicles have in common. I also added a background that shows the 
factory, however, I still have to adjust it properly to fit the entire
screen or more of the screen and not just the center of the borderlayout.
All of the move buttons have functionality and work to move only the 
Factory Worker for now. I intend on making the buttons work on all the 
vehicles. I also need to change the move buttons so that they move 
the vehicles respective to their original position and not to the 
same coordinates everytime a "Move Right" button (for example) is
pressed. 

More additions: 

The Manager, Worker, and Custodian all move once the "Start Animation"
button is clicked. They stop moving once the "Stop Animation" button
is clicked. The label of the button changes once that specific button
is clicked. I also implemented an add function where the user can choose
a specific vehicle to add. The buttons that move the vehicle left, right, up, 
and down only apply to one of my vehicles and not all of them. A text 
field was also added to the program that allows the user to set the speed of
the vehicle. 

Include your Design Documentation (outlined in “Programming and design 
documentation practices”)

Inheritance Hierarchy: 
Super Class --> Child Class 

JButton --> Button
JPanel --> Canvas 
JPanel --> Radio
JComboBox --> ComboBox 
JFrame --> Main
JPanel --> Manager
JPanel --> Vehicle
Vehicle --> Worker
Vehicle --> Manager
Vehicle --> Custodian 
JPanel --> Background

Aggregation Hierarchy:                   
Object ---> Component ---> Canvas (1)
                                          
Object ---> Component ---> Button (6)            
                                         ---> Panel p2
Object ---> Component ---> Combo Box (1) 

Object ---> Component ---> Radio (1) ---> Panel p3

Object --> Component --> Panel 

Object --> Panel --> Background 

Object --> Panel --> Vehicle --> Worker & Manager & Custodian 


Acknowledgements:
I swearched up how to use the borderlayout and how to get the color maroon. 
I used oracle to get most of my information. I also used snippets of code 
from my Professor in class and from my previous hw1, hw2, hw3, and hw4 
assignment. 

