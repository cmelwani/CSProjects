//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file sets up the object Manager that has a specific 
//icon and features. It extends JPanel and an is called in Model. 

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Manager extends Vehicle {
    ImageIcon icon1;
    private Main parent;
    private int row;
    private int column;

    Manager(Main parent, int x, int y) {
        this.row = x;
        this.column = y;
        this.parent = parent;
        icon1 = new ImageIcon ("manager.png");
    }

    public int getX() {
        return row;
    }

    public int getY() {
        return column;
    }

    public void move(int x, int y) {
        row = x;
        column = y;
    }

    public void tick() {
        row = row + (20 + parent.getFrameNumber());
        column = column + (20 + parent.getFrameNumber());     
    }

    public void draw(Graphics g) {
        icon1.paintIcon(this, g, row, column);
    }
}