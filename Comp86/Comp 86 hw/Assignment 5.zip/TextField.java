//Name: Cheryl Melwani
//Email: cheryl.melwani@tufts.edu
//Description: This file creates a textfield that's used in the program
//This file takes the speed of the vehicle in question

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class TextField extends JTextField implements ActionListener {
    public TextField () {
	super ("Inteded Speed", 20); 
	addActionListener (this);
    }

    public void actionPerformed (ActionEvent e) { 
	System.out.println ("Text: " + e.getActionCommand()); 
    }
}
