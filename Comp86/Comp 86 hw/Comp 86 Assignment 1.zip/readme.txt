Details:
    Cheryl Melwani
    Comp86 Assignment 1
    Sophomore Class (Year of 2023)
Outline of the Program: 
    The program creates a window that has multiple widgets including a 
    Button, a Text Field, a Combo Box and a Scroll Bar. 
    Each specific instance of a widget prints out a specific message 
    on the standard output. 
Acknowledgements:
    I used a couple of websites to figure out some Java syntax such as
    stackoverflow. 
    I also worked with another student in the class: Sohini Shah to do 
    some research on a component of the program. 
How to compile the program: 
    Step 1: javac Main.java
    Step 2: java Main 